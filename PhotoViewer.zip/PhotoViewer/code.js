document.getElementById("PhotoLink").value = "InitialImage.jpg";

const buttons = document.querySelectorAll('button[type="button"]');

const img = document.getElementById("currimg");

let currNum = 0;

let namesList = [];

let slideshowInterval;

/* LAMBDA */ 
buttons.forEach(button => {
    button.onclick = function(event) {
        if (event.target.id === 'LoadPs') {
            loadPhotos();
        }
        
        else if (event.target.id === "LoadJSON"){
            loadJSON();
        }

        else if (event.target.id === "PrevP"){
            prevPhoto();
            
        }

        else if (event.target.id === "NextP"){
            nextPhoto();
        }

        else if (event.target.id === "FirstP"){
            firstPhoto();
        }

        else if (event.target.id === "LastP"){
            lastPhoto();
        }

        else if (event.target.id === "Slide"){
            Slideshow();
        }

        else if (event.target.id === "RandSlide"){
            RandomSlideshow();
        }

        else if (event.target.id === "StopSlide"){
            StopSlideshow();
        }
    };
});


function loadPhotos(){


    const folder = document.querySelector("#Folder").value;
    const common = document.querySelector("#Common").value;
    const start = parseInt(document.querySelector("#StartNum").value);
    const end = parseInt(document.querySelector("#EndNum").value);

    // src = folder + common name + start + end 

    namesList = [];
    

    if (end < start){
        document.getElementById("loaded").textContent = "Error: Invalid Range";
    }

    else if (folder && common && start && end){
        document.getElementById("loaded").textContent = "Photo Viewer System";

        for (let i  = start; i <= end; i++){
            const name = folder + common + i + ".jpg";
            namesList.push(name);
        }

        currNum = 0;
        img.src = namesList[currNum];
        document.getElementById("PhotoLink").value = namesList[currNum];

    }
    
    return namesList;

}

function prevPhoto(){

    if (namesList.length === 0){
        document.getElementById("loaded").textContent = "Error: you must load data first";
    }

    else if (currNum > 0){
        currNum--; 
        img.src = namesList[currNum];
        document.getElementById("PhotoLink").value = namesList[currNum];
    }
}

function nextPhoto(){
    
    if (namesList.length === 0){
        document.getElementById("loaded").textContent = "Error: you must load data first";
    }

    else if (currNum < namesList.length - 1){
        currNum++;
        img.src = namesList[currNum];
        document.getElementById("PhotoLink").value = namesList[currNum];
    }

}

function firstPhoto(){
    if (namesList.length === 0){
        document.getElementById("loaded").textContent = "Error: you must load data first";
    }

    else{
        currNum = 0;
        img.src = namesList[currNum];
        document.getElementById("PhotoLink").value = namesList[currNum];
    }
}

function lastPhoto(){
    if (namesList.length === 0){
        document.getElementById("loaded").textContent = "Error: you must load data first";
    }

    else{
        currNum = namesList.length-1;
        img.src = namesList[currNum];
        document.getElementById("PhotoLink").value = namesList[currNum];
    }
}

function Slideshow() {
    if (namesList.length === 0) {
        document.getElementById("loaded").textContent = "Error: you must load data first";
    }


    else {
        let delay = 1000;

        slideshowInterval = setInterval(function() {
            currNum++;

            if (currNum >= namesList.length) { 
                currNum = 0; 
            }
            
            img.src = namesList[currNum]; 
            document.getElementById("PhotoLink").value = namesList[currNum];
        }, delay);
    }

}

function RandomSlideshow() {
    if (namesList.length === 0) {
        document.getElementById("loaded").textContent = "Error: you must load data first";
    }

    else
    {
        let delay = 1000;

        slideshowInterval = setInterval(function() {
            let rand = Math.floor(Math.random() * namesList.length);

            img.src = namesList[rand];
            
            document.getElementById("PhotoLink").value = namesList[rand];
        }, delay);
    }
}

function StopSlideshow(){
    if (slideshowInterval) {
        clearInterval(slideshowInterval);
        slideshowInterval = null;
    }
}

function loadJSON() {
    const link = document.getElementById("url").value; 

    fetch(link) 
        .then(response => response.json()) 
        .then(data => {
            namesList = []; 

            /* LAMBDA */ 
            data.images.forEach(image => {
                namesList.push(image.imageURL);
            });

            currNum = 0;
            img.src = namesList[currNum]; 
            document.getElementById("PhotoLink").value = namesList[currNum];
        });
}


// "Nelson likes to drink coffee." i also like to drink coffee, i had 3 cups today...it's 1 am